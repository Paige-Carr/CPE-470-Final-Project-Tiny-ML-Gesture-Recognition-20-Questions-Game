/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#if defined(ARDUINO) && !defined(ARDUINO_ARDUINO_NANO33BLE)
#define ARDUINO_EXCLUDE_CODE
#endif  // defined(ARDUINO) && !defined(ARDUINO_ARDUINO_NANO33BLE)

#ifndef ARDUINO_EXCLUDE_CODE

#include "detection_responder.h"
#include "QuestionTree.h"
#include "Arduino.h"

// Confidence threshold: both scores must differ by at least this amount
// for a result to be considered confident (not "unknown").
// Range is roughly 0.0–1.0 after dequantization. Tune as needed.
constexpr float kConfidenceThreshold = 0.3f;

// Helper: print the current node's prompt to Serial
static void PrintCurrentPrompt() {
  if (!currentNode) {
    Serial.println("[ERROR] currentNode is null — call ResetGame() first.");
    return;
  }

  if (currentNode->isGuess) {
    // We have reached a leaf: make the guess, then automatically reset.
    Serial.print("My guess is: ");
    Serial.println(currentNode->text);
    Serial.println("Was I right? (Starting a new game...)");
    // Small pause so the player can read the guess before the tree resets.
    delay(4000);
    ResetGame();
    Serial.println("--- New Game ---");
    Serial.println(currentNode->text);  // Print the first question of the new game
  } else {
    Serial.println(currentNode->text);
  }
}

void RespondToDetection(tflite::ErrorReporter* error_reporter,
                        float thumbs_up_score, float thumbs_down_score) {
  static bool is_initialized = false;
  if (!is_initialized) {
    // Pins for the built-in RGB LEDs on the Arduino Nano 33 BLE Sense.
    // Note: LEDs are ACTIVE LOW — LOW = on, HIGH = off.
    pinMode(LEDR, OUTPUT);
    pinMode(LEDG, OUTPUT);
    pinMode(LEDB, OUTPUT);

    // Start with all LEDs off
    digitalWrite(LEDR, HIGH);
    digitalWrite(LEDG, HIGH);
    digitalWrite(LEDB, HIGH);

    // Initialize the 20-questions game tree.
    ResetGame();
    Serial.println("=== 20 Questions ===");
    PrintCurrentPrompt();

    is_initialized = true;
  }

  // ── Step 1: Blue LED ON while processing ─────────────────────────────────
  // Blue is already on while the picture was taken and the model ran
  // (turned on in loop() before calling this function).
  // Turn off red/green from any previous result while blue is showing.
  digitalWrite(LEDR, HIGH);
  digitalWrite(LEDG, HIGH);
  digitalWrite(LEDB, LOW);   // blue ON

  // Brief pause so the blue LED is visible before showing the result.
  delay(500);

  // ── Step 2: Turn blue off, show result ───────────────────────────────────
  digitalWrite(LEDB, HIGH);  // blue OFF

  float margin = thumbs_up_score - thumbs_down_score;  // positive → thumbs up wins

  if (fabsf(margin) < kConfidenceThreshold) {
    // ── UNKNOWN: confidence too low ─────────────────────────────────────
    // Blink blue rapidly to signal "unknown / retrying"
    Serial.println("Result: UNKNOWN (low confidence) — retrying...");
    TF_LITE_REPORT_ERROR(error_reporter,
                         "Unknown - thumbs_up: %d  thumbs_down: %d",
                         (int)(thumbs_up_score * 100),
                         (int)(thumbs_down_score * 100));

    // Blink blue 3 times to clearly indicate unknown state
    for (int i = 0; i < 3; i++) {
      digitalWrite(LEDB, LOW);
      delay(150);
      digitalWrite(LEDB, HIGH);
      delay(150);
    }
    // Return without showing red or green — loop() will call us again
    // immediately, repeating until confidence is sufficient.
    return;
  }

  if (margin > 0) {
    // ── THUMBS UP ────────────────────────────────────────────────────────
    Serial.println("Result: THUMBS UP");
    // TF_LITE_REPORT_ERROR(error_reporter,
    //                      "Thumbs up - score: %d%%",
    //                      (int)(thumbs_up_score * 100));
    digitalWrite(LEDG, LOW);   // green ON
    digitalWrite(LEDR, HIGH);  // red OFF

    AnswerYes();

  } else {
    // ── THUMBS DOWN ──────────────────────────────────────────────────────
    Serial.println("Result: THUMBS DOWN");
    // TF_LITE_REPORT_ERROR(error_reporter,
    //                      "Thumbs down - score: %d%%",
    //                      (int)(thumbs_down_score * 100));
    digitalWrite(LEDR, LOW);   // red ON
    digitalWrite(LEDG, HIGH);  // green OFF

    AnswerNo();

  }

  // Hold the result LED on for 3 seconds so it is clearly visible,
  // then turn it off before the next inference cycle begins.
  delay(3000);
  digitalWrite(LEDR, HIGH);
  digitalWrite(LEDG, HIGH);

    // Print the next question (or guess)
  PrintCurrentPrompt();

  // Pause so the player has time to read before the next inference begins.
  delay(3000);
}

#endif  // ARDUINO_EXCLUDE_CODE
