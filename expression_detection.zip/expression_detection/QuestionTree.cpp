#include "QuestionTree.h"

Node* currentNode = nullptr;

Node* BuildTree()
{
    // ==================================================
    // LEAF NODES (OBJECTS)
    // ==================================================

    static Node dog        = {"Dog",        nullptr, nullptr, true};
    static Node cat        = {"Cat",        nullptr, nullptr, true};
    static Node fish       = {"Fish",       nullptr, nullptr, true};
    static Node bird       = {"Bird",       nullptr, nullptr, true};
    static Node horse      = {"Horse",      nullptr, nullptr, true};

    static Node tree       = {"Tree",       nullptr, nullptr, true};
    static Node flower     = {"Flower",     nullptr, nullptr, true};
    static Node apple      = {"Apple",      nullptr, nullptr, true};

    static Node phone      = {"Phone",      nullptr, nullptr, true};
    static Node laptop     = {"Laptop",     nullptr, nullptr, true};
    static Node television = {"Television", nullptr, nullptr, true};
    static Node camera     = {"Camera",     nullptr, nullptr, true};

    static Node car        = {"Car",        nullptr, nullptr, true};
    static Node bicycle    = {"Bicycle",    nullptr, nullptr, true};
    static Node airplane   = {"Airplane",   nullptr, nullptr, true};
    static Node boat       = {"Boat",       nullptr, nullptr, true};

    static Node chair      = {"Chair",      nullptr, nullptr, true};
    static Node table      = {"Table",      nullptr, nullptr, true};
    static Node bed        = {"Bed",        nullptr, nullptr, true};
    static Node lamp       = {"Lamp",       nullptr, nullptr, true};

    static Node pizza      = {"Pizza",      nullptr, nullptr, true};
    static Node banana     = {"Banana",     nullptr, nullptr, true};
    static Node hamburger  = {"Hamburger",  nullptr, nullptr, true};

    static Node hammer     = {"Hammer",     nullptr, nullptr, true};
    static Node guitar     = {"Guitar",     nullptr, nullptr, true};

    // ==================================================
    // ANIMAL BRANCH
    // ==================================================

    static Node petQuestion =
    {
        "Is it commonly kept as a pet?",
        &dog,
        &cat,
        false
    };

    static Node underwaterQuestion =
    {
        "Does it live underwater?",
        &fish,
        &petQuestion,
        false
    };

    static Node flyQuestion =
    {
        "Can it fly?",
        &bird,
        &underwaterQuestion,
        false
    };

    static Node animalSizeQuestion =
    {
        "Is it larger than a person?",
        &horse,
        &flyQuestion,
        false
    };

    // ==================================================
    // PLANT BRANCH
    // ==================================================

    static Node treeOrFlowerQuestion =
    {
        "Is it typically taller than a person?",
        &tree,
        &flower,
        false
    };

    static Node plantQuestion =
    {
        "Does it produce edible fruit?",
        &apple,
        &treeOrFlowerQuestion,
        false
    };

    // ==================================================
    // LIVING THINGS
    // ==================================================

    static Node livingQuestion =
    {
        "Is it an animal?",
        &animalSizeQuestion,
        &plantQuestion,
        false
    };

    // ==================================================
    // FOOD BRANCH
    // ==================================================

    static Node pizzaOrBurgerQuestion =
    {
        "Is it round?",
        &pizza,
        &hamburger,
        false
    };

    static Node hotFoodQuestion =
    {
        "Is it usually eaten hot?",
        &pizzaOrBurgerQuestion,
        &banana,
        false
    };

    // ==================================================
    // ELECTRONICS BRANCH
    // ==================================================

    static Node phoneOrLaptopQuestion =
    {
        "Does it primarily make phone calls?",
        &phone,
        &laptop,
        false
    };

    static Node cameraOrTVQuestion =
    {
        "Is it primarily used for taking pictures?",
        &camera,
        &television,
        false
    };

    static Node portableQuestion =
    {
        "Is it portable?",
        &phoneOrLaptopQuestion,
        &cameraOrTVQuestion,
        false
    };

    // ==================================================
    // VEHICLE BRANCH
    // ==================================================

    static Node engineQuestion =
    {
        "Does it have an engine?",
        &car,
        &bicycle,
        false
    };

    static Node waterVehicleQuestion =
    {
        "Does it travel on water?",
        &boat,
        &engineQuestion,
        false
    };

    static Node vehicleQuestion =
    {
        "Can it fly?",
        &airplane,
        &waterVehicleQuestion,
        false
    };

    // ==================================================
    // FURNITURE BRANCH
    // ==================================================

    static Node lampOrTableQuestion =
    {
        "Does it provide light?",
        &lamp,
        &table,
        false
    };

    static Node chairQuestion =
    {
        "Is it used for sitting?",
        &chair,
        &lampOrTableQuestion,
        false
    };

    static Node furnitureQuestion =
    {
        "Is it used for sleeping?",
        &bed,
        &chairQuestion,
        false
    };

    // ==================================================
    // TOOLS / MISC BRANCH
    // ==================================================

    static Node miscQuestion =
    {
        "Is it used for construction or repair work?",
        &hammer,
        &guitar,
        false
    };

    // ==================================================
    // NON-FURNITURE BRANCH
    // ==================================================

    static Node furnitureCheckQuestion =
    {
        "Is it furniture?",
        &furnitureQuestion,
        &miscQuestion,
        false
    };

    // ==================================================
    // NON-LIVING BRANCH
    // ==================================================

    static Node vehicleCheckQuestion =
    {
        "Is it a vehicle?",
        &vehicleQuestion,
        &furnitureCheckQuestion,
        false
    };

    static Node electronicsCheckQuestion =
    {
        "Is it electronic?",
        &portableQuestion,
        &vehicleCheckQuestion,
        false
    };

    static Node nonLivingQuestion =
    {
        "Is it food?",
        &hotFoodQuestion,
        &electronicsCheckQuestion,
        false
    };

    // ==================================================
    // ROOT
    // ==================================================

    static Node root =
    {
        "Is it alive?",
        &livingQuestion,
        &nonLivingQuestion,
        false
    };

    return &root;
}

void ResetGame()
{
    currentNode = BuildTree();
}

void AnswerYes()
{
    if (currentNode && !currentNode->isGuess)
        currentNode = currentNode->yes;
}

void AnswerNo()
{
    if (currentNode && !currentNode->isGuess)
        currentNode = currentNode->no;
}
