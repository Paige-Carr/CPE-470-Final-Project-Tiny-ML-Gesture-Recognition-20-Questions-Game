#ifndef QUESTION_TREE_H
#define QUESTION_TREE_H

#include "Node.h"

// Builds the static decision tree and returns a pointer to the root node.
Node* BuildTree();

// Pointer to the node currently being evaluated during a game.
extern Node* currentNode;

// Resets the game back to the root of the tree.
void ResetGame();

// Advances the tree along the "Yes" branch (thumbs up).
void AnswerYes();

// Advances the tree along the "No" branch (thumbs down).
void AnswerNo();

#endif  // QUESTION_TREE_H
