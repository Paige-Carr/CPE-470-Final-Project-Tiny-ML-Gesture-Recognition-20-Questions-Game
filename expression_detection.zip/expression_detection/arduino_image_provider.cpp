/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at
  http://www.apache.org/licenses/LICENSE-2.0
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  ==============================================================================*/
#include "image_provider.h"
#include "Arduino.h"
#include <TinyMLShield.h>

#ifndef ARDUINO_EXCLUDE_CODE


// #include <Arduino_OV767X.h>

TfLiteStatus GetImage(tflite::ErrorReporter* error_reporter, int image_width,
                      int image_height, int channels, int8_t* image_data) {

  byte data[160 * 120];  // QQVGA grayscale

  static bool g_is_camera_initialized = false;

  if (!g_is_camera_initialized) {
    if (!Camera.begin(QQVGA, GRAYSCALE, 5, OV7675)) {  // changed QCIF to QQVGA
      TF_LITE_REPORT_ERROR(error_reporter, "Failed to initialize camera!");
      return kTfLiteError;
    }
    g_is_camera_initialized = true;
  }

  // READ FRAME
  Camera.readFrame(data);

  // VISUALIZER
  // Stream frame to Processing visualizer
  // Serial.write(0xFF);
  // Serial.write(0xAA);
  // Serial.write(data, 160 * 120);


  // Be explicit about layout: 120 rows, 160 cols
  for (int row = 0; row < 120; row++) {
    for (int col = 0; col < 160; col++) {
      int src_idx = row * 160 + col;
      int dst_idx = row * 160 + col; // same if no transpose needed
      image_data[dst_idx] = static_cast<int8_t>(data[src_idx] - 128);
    }
  }

  return kTfLiteOk;
}

#endif  // ARDUINO_EXCLUDE_CODE