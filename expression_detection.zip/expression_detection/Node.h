#ifndef NODE_H
#define NODE_H

struct Node {
    const char* text;   // Question text or guess (object name)
    Node* yes;          // Branch taken on "Yes" answer
    Node* no;           // Branch taken on "No" answer
    bool isGuess;       // True when this is a leaf (object), false when a question
};

#endif  // NODE_H
