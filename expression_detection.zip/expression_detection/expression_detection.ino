/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include <TensorFlowLite.h>

#include "main_functions.h"
#include "test_image_data.h"

#include "detection_responder.h"
#include "image_provider.h"
#include "model_settings.h"
#include "expression_detect_model_data.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/version.h"
#include "tensorflow/lite/c/common.h"


// Globals, used for compatibility with Arduino-style sketches.
namespace {
tflite::ErrorReporter* error_reporter = nullptr;
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
bool initialized = false;
bool resolver_ready = false;
bool interpreter_ready = false;
bool allocate_flag = false;
bool input_flag = false;

// An area of memory to use for input, output, and intermediate arrays.
constexpr int kTensorArenaSize = 200 * 1024;
static uint8_t tensor_arena[kTensorArenaSize];
}  // namespace

// The name of this function is important for Arduino compatibility.
void setup() {
  Serial.begin(115200);

  // Set up LEDs — all off initially (active low: HIGH = off)
  pinMode(LEDR, OUTPUT);
  pinMode(LEDG, OUTPUT);
  pinMode(LEDB, OUTPUT);
  digitalWrite(LEDR, HIGH);
  digitalWrite(LEDG, HIGH);
  digitalWrite(LEDB, HIGH);

  static tflite::MicroErrorReporter micro_error_reporter;
  error_reporter = &micro_error_reporter;

  // Map the model into a usable data structure.
  model = tflite::GetModel(g_expression_detect_model_data);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    TF_LITE_REPORT_ERROR(error_reporter,
                         "Model provided is schema version %d not equal "
                         "to supported version %d.",
                         model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }

  static tflite::MicroMutableOpResolver<5> micro_op_resolver;
  micro_op_resolver.AddConv2D();
  micro_op_resolver.AddMaxPool2D();
  micro_op_resolver.AddMean();
  micro_op_resolver.AddFullyConnected();
  micro_op_resolver.AddSoftmax();

  resolver_ready = true;

  static tflite::MicroInterpreter static_interpreter(
      model, micro_op_resolver, tensor_arena, kTensorArenaSize, error_reporter);
  interpreter = &static_interpreter;

  interpreter_ready = true;

  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter, "AllocateTensors() failed");
    return;
  }

  allocate_flag = true;

  input = interpreter->input(0);
  input_flag = true;

  initialized = true;
  // Serial.println("Setup complete.");
}


// The name of this function is important for Arduino compatibility.
void loop() {

  if (!resolver_ready || !interpreter_ready || !allocate_flag ||
      !input_flag    || !initialized) {
    TF_LITE_REPORT_ERROR(error_reporter, "Setup incomplete — halting.");
    return;
  }

  // ── BLUE LED ON: taking picture + running model ───────────────────────────
  digitalWrite(LEDR, HIGH);
  digitalWrite(LEDG, HIGH);
  digitalWrite(LEDB, LOW);   // blue ON

  // Serial.println("Taking picture...");
  if (kTfLiteOk != GetImage(error_reporter, kNumCols, kNumRows, kNumChannels,
                            input->data.int8)) {
    TF_LITE_REPORT_ERROR(error_reporter, "Image capture failed.");
    digitalWrite(LEDB, HIGH);
    return;
  }

  // Serial.println("Loading image");
  // // Copy test image directly into the model's input tensor
  // memcpy(input->data.int8, test_image_data, kNumCols * kNumRows * kNumChannels);


  // Serial.println("Running model...");
  if (kTfLiteOk != interpreter->Invoke()) {
    TF_LITE_REPORT_ERROR(error_reporter, "Invoke failed.");
    digitalWrite(LEDB, HIGH);
    return;
  }

  TfLiteTensor* output = interpreter->output(0);

  // Dequantize: real_value = scale * (quantized_value - zero_point)
  float scale      = output->params.scale;
  int   zero_point = output->params.zero_point;
  float thumbs_up_score   = scale * (output->data.int8[kHappyIndex] - zero_point);
  float thumbs_down_score = scale * (output->data.int8[kSadIndex]   - zero_point);

  // Serial.print("Thumbs up:   "); Serial.println(thumbs_up_score);
  // Serial.print("Thumbs down: "); Serial.println(thumbs_down_score);

  // ── Hand off to responder (blue LED handed off, result LED set there) ─────
  // Blue LED is still ON here; RespondToDetection() manages the transition.
  RespondToDetection(error_reporter, thumbs_up_score, thumbs_down_score);

  // At the bottom of loop(), before the closing brace:
  delay(5000);  // wait 5 seconds between inferences

}
